Place where original images are stored
