various file I want to keep but not in the active project anymore
